const fallback = "assets/placeholders/logo-placeholder.svg";
let logos = [];

async function init(){
  const res = await fetch("logos-manifest.json");
  logos = await res.json();

  renderCompetitions();
  renderClubs("all");
  setupFilters();
}

function makeImg(item){
  const img = document.createElement("img");
  img.src = item.image;
  img.alt = item.name;
  img.onerror = () => img.src = fallback;
  return img;
}

function renderCompetitions(){
  const el = document.getElementById("competitionCarousel");
  const comps = logos.filter(x => x.type === "competition");
  const loop = [...comps, ...comps, ...comps];

  el.innerHTML = "";
  loop.forEach(item => {
    const pill = document.createElement("div");
    pill.className = "logo-pill";
    pill.appendChild(makeImg(item));
    const span = document.createElement("span");
    span.textContent = item.name;
    pill.appendChild(span);
    el.appendChild(pill);
  });
}

function renderClubs(filter){
  const grid = document.getElementById("clubGrid");
  let clubs = logos.filter(x => x.type === "club");
  if(filter !== "all") clubs = clubs.filter(x => x.country === filter);

  grid.innerHTML = "";
  clubs.forEach(item => {
    const card = document.createElement("div");
    card.className = "card";
    card.appendChild(makeImg(item));

    const name = document.createElement("strong");
    name.textContent = item.name;

    const country = document.createElement("small");
    country.textContent = item.country;

    card.appendChild(name);
    card.appendChild(country);
    grid.appendChild(card);
  });
}

function setupFilters(){
  document.querySelectorAll(".filter").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      renderClubs(btn.dataset.filter);
    });
  });
}

init();