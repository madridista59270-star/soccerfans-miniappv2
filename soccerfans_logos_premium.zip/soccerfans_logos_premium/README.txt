SOCCER FANS - PACK LOGOS PREMIUM

À envoyer sur GitHub :
- index.html
- logos-manifest.json
- dossier assets
- dossier css
- dossier js

Ajoute tes logos PNG ici :
- assets/logos/competitions/
- assets/logos/france/
- assets/logos/espagne/
- assets/logos/angleterre/
- assets/logos/italie/
- assets/logos/allemagne/
- assets/logos/europe/

Respecte exactement les chemins du fichier :
logos-a-remplir.csv
